const Config = {
  USER_TOKEN_KEY: 'tk',
  USERNAME_KEY: 'unk'
};
export default Config;
