// Do not modify this file by hand!
// Re-generate this file by running lit-localize

/* eslint-disable no-irregular-whitespace */

export const templates = {
  s02b1df68b12ac3ab: 'lalisa ngai libanda',
  s0cdb6b5e0e4dc4af: 'tika ngai',
  s229fb4df9ecf3ed1: 'bima libanda',
  s8d9d6501de2bbd98: 'kobakisa ba données',
  sa352675d34c960bf: 'Esalemi na ❤ na Robby',
  sf9a862bfd829397e: 'Tableau de bord'
};
