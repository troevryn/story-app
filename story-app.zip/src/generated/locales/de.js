// Do not modify this file by hand!
// Re-generate this file by running lit-localize

export const templates = {
  s02b1df68b12ac3ab: 'Leg mich hin',
  s0cdb6b5e0e4dc4af: 'Karten hinterlassen',
  s229fb4df9ecf3ed1: 'hinausgehen',
  s8d9d6501de2bbd98: 'Daten hinzufügen',
  sa352675d34c960bf: 'Hergestellt mit ❤ von Robby',
  sf9a862bfd829397e: 'Dashboards'
};
